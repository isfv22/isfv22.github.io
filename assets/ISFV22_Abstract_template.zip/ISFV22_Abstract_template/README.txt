ISFV22 — Abstract template
22nd International Symposium on Flow Visualization, 11–15 July 2027, Madrid (UC3M).
Single-column layout. Authors are listed inline; affiliations go below, keyed by superscripts.
Provided in two formats: LaTeX (.tex/.cls/.sty) and Word (.docx).

Files
  isfv22_abstract_template.tex  – main file (edit your title, authors, sections here)
  isfv22.cls                    – document class (header with the ISFV logo, layout)
  isfv22.sty                    – font/size settings used by the class
  isfv22_references.bib         – example bibliography (replace with your references)
  Figures/ISFV22.png            – ISFV logo (used in the header; also an example figure, commented in the .tex)
  isfv22_abstract_template.pdf  – sample compiled output (LaTeX)
  ISFV22_Abstract_template.docx – Word version of the same template

How to compile
  pdflatex isfv22_abstract_template
  bibtex   isfv22_abstract_template
  pdflatex isfv22_abstract_template
  pdflatex isfv22_abstract_template
(Or just upload the folder to Overleaf and compile.)

Notes
  - The header text and dates are set in isfv22.cls (\@maketitle).
  - Replace Figures/ISFV22.png usage in the body with your own figure when ready.
