ISFV22 — Abstract template
22nd International Symposium on Flow Visualization, 11–15 July 2027, Madrid (UC3M).
Single-column layout. Authors are listed inline; affiliations go below, keyed by superscripts.
Provided in two formats: LaTeX (.tex/.cls/.sty) and Word (.docx).
Length: at most two pages, including figures, tables and references (no word limit);
submit a single PDF of no more than 20 MB.
Licence: every abstract must carry a Creative Commons licence, printed in the page footer.
  CC BY 4.0 (Attribution)                  -> \documentclass{isfv22}
  CC BY-ND 4.0 (Attribution-NoDerivatives) -> \documentclass[license_nd]{isfv22}
  Word: use the template that matches your chosen licence (CC-BY or CC-BY-ND).
Presenting author: state who will present the work (\presenter{...} in LaTeX; the "Presenting author:" line in Word). If unchanged or left empty, the corresponding author is assumed.
Keywords: 3-6 keywords (\keywords{...} in LaTeX; the "Keywords:" line in Word) are used by the Scientific Committee to assign the topic.

Files
  isfv22_abstract_template.tex  – main file (edit your title, authors, sections here)
  isfv22.cls                    – document class (header with the ISFV logo, layout)
  isfv22.sty                    – font/size settings used by the class
  isfv22_references.bib         – example bibliography (replace with your references)
  Figures/ISFV22.png            – ISFV logo (used in the header; also an example figure, commented in the .tex)
  isfv22_abstract_template.pdf  – sample compiled output (LaTeX, CC BY)
  ISFV22_Abstract_template_CC-BY.docx    – Word template, licence CC BY 4.0
  ISFV22_Abstract_template_CC-BY-ND.docx – Word template, licence CC BY-ND 4.0

How to compile
  pdflatex isfv22_abstract_template
  bibtex   isfv22_abstract_template
  pdflatex isfv22_abstract_template
  pdflatex isfv22_abstract_template
(Or just upload the folder to Overleaf and compile.)

Notes
  - The header text and dates are set in isfv22.cls (\@maketitle).
  - Replace Figures/ISFV22.png usage in the body with your own figure when ready.
